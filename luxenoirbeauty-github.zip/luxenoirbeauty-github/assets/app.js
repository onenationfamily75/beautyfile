
const fmt = n => '€' + n.toFixed(2);
const cart = {
  get(){ try{return JSON.parse(localStorage.getItem('lnb_cart')||'[]')}catch(e){return []} },
  set(v){ localStorage.setItem('lnb_cart', JSON.stringify(v)); render(); },
  add(p, qty=1){ const c=this.get(); const e=c.find(x=>x.id===p.id); if(e) e.qty+=qty; else c.push({id:p.id,name:p.name,brand:p.brand,price:p.price,img:p.img,qty}); this.set(c); openCart(); },
  remove(id){ this.set(this.get().filter(x=>x.id!==id)); },
  count(){ return this.get().reduce((s,x)=>s+x.qty,0); },
  total(){ return this.get().reduce((s,x)=>s+x.qty*x.price,0); },
  clear(){ this.set([]); }
};
let PRODUCTS=[];
async function loadProducts(){
  const r = await fetch('assets/products.json');
  PRODUCTS = await r.json();
  renderCats(); renderGrid('All');
}
function renderCats(){
  const cats=['All',...new Set(PRODUCTS.map(p=>p.category))];
  const wrap=document.getElementById('cats'); if(!wrap) return;
  wrap.innerHTML=cats.map((c,i)=>`<button class="${i===0?'active':''}" data-c="${c}">${c}</button>`).join('');
  wrap.querySelectorAll('button').forEach(b=>b.onclick=()=>{
    wrap.querySelectorAll('button').forEach(x=>x.classList.remove('active'));
    b.classList.add('active'); renderGrid(b.dataset.c);
  });
}
function renderGrid(cat){
  const grid=document.getElementById('grid'); if(!grid) return;
  const list = cat==='All'?PRODUCTS:PRODUCTS.filter(p=>p.category===cat);
  grid.innerHTML = list.map(p=>`
    <div class="card" data-id="${p.id}">
      <div class="card-img"><img src="${p.img}" alt="${p.name}" loading="lazy"></div>
      <div class="card-body">
        <div class="card-brand">${p.brand}</div>
        <div class="card-name">${p.name}</div>
        <div class="card-price">${fmt(p.price)}</div>
        <div class="card-actions">
          <button class="btn detail-btn">Details</button>
          <button class="btn btn-primary add-btn">Add to Cart</button>
        </div>
      </div>
    </div>`).join('');
  grid.querySelectorAll('.card').forEach(c=>{
    const id=c.dataset.id; const p=PRODUCTS.find(x=>x.id===id);
    c.querySelector('.detail-btn').onclick=e=>{e.stopPropagation();openModal(p)};
    c.querySelector('.add-btn').onclick=e=>{e.stopPropagation();cart.add(p)};
    c.querySelector('.card-img').onclick=()=>openModal(p);
  });
}
function openModal(p){
  let qty=1;
  const m=document.getElementById('modal');
  m.innerHTML=`<div class="modal-inner" style="position:relative">
    <button class="close">&times;</button>
    <img src="${p.img}" alt="">
    <div class="modal-body">
      <div class="card-brand">${p.brand} · ${p.category}</div>
      <h2>${p.name}</h2>
      <p>${p.desc}</p>
      <div class="price">${fmt(p.price)}</div>
      <div class="qty"><span>Quantity</span>
        <button id="qm">−</button><span id="qv">1</span><button id="qp">+</button>
      </div>
      <div class="modal-actions">
        <button class="btn add">Add to Cart</button>
        <button class="btn btn-primary buy">Buy Now</button>
      </div>
    </div></div>`;
  m.classList.add('open');
  m.querySelector('.close').onclick=()=>m.classList.remove('open');
  m.onclick=e=>{ if(e.target===m) m.classList.remove('open'); };
  m.querySelector('#qm').onclick=()=>{qty=Math.max(1,qty-1);m.querySelector('#qv').textContent=qty};
  m.querySelector('#qp').onclick=()=>{qty++;m.querySelector('#qv').textContent=qty};
  m.querySelector('.add').onclick=()=>{cart.add(p,qty);m.classList.remove('open')};
  m.querySelector('.buy').onclick=()=>{cart.add(p,qty);m.classList.remove('open');location.href='checkout.html'};
}
function openCart(){document.getElementById('drawer').classList.add('open');render()}
function closeCart(){document.getElementById('drawer').classList.remove('open')}
function render(){
  const cnt=document.getElementById('cart-count'); if(cnt) cnt.textContent=cart.count();
  const items=document.getElementById('cart-items'); if(!items) return;
  const c=cart.get();
  if(!c.length){ items.innerHTML='<div class="empty">Your cart is empty</div>'; }
  else{
    items.innerHTML=c.map(x=>`
      <div class="cart-item">
        <img src="${x.img}">
        <div>
          <div class="name">${x.name}</div>
          <div class="meta">${x.brand} · Qty ${x.qty}</div>
          <button class="rm" data-id="${x.id}">Remove</button>
        </div>
        <div style="font-family:Inter,sans-serif;color:var(--gold)">${fmt(x.price*x.qty)}</div>
      </div>`).join('');
    items.querySelectorAll('.rm').forEach(b=>b.onclick=()=>cart.remove(b.dataset.id));
  }
  const tot=document.getElementById('cart-total'); if(tot) tot.textContent=fmt(cart.total());
}
document.addEventListener('DOMContentLoaded',()=>{
  loadProducts();
  const cb=document.getElementById('cart-toggle'); if(cb) cb.onclick=openCart;
  const cc=document.getElementById('cart-close'); if(cc) cc.onclick=closeCart;
  const co=document.getElementById('cart-checkout'); if(co) co.onclick=()=>location.href='checkout.html';
  render();
});
