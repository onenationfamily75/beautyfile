# LUXE NOIR BEAUTY — luxenoirbeauty.shop

> **Luxury beauty storefront** · Fragrance · Skincare · Makeup · 200+ products · Worldwide shipping

Static, deployable luxury beauty storefront featuring 200+ real products: Chanel, Dior, Tom Ford, YSL, La Mer, SK-II, Byredo, Charlotte Tilbury, Fenty Beauty, NARS, Olaplex, Diptyque, Amouage, Creed, Le Labo, Maison Francis Kurkdjian, and more.

---

## 🚀 Deploy to GitHub Pages (Step-by-Step)

### Step 1 — Create the Repository
1. Go to [github.com/new](https://github.com/new)
2. Name it exactly: `luxenoirbeauty` (or `luxenoirbeauty.github.io` to serve at the root)
3. Set visibility: **Public**
4. Click **Create repository**

### Step 2 — Upload Files
```bash
git init
git add .
git commit -m "Initial deploy — LUXE NOIR BEAUTY storefront"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/luxenoirbeauty.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: `main` · Folder: `/ (root)`
4. Click **Save**
5. Your site goes live at: `https://YOUR_USERNAME.github.io/luxenoirbeauty/`

### Step 4 — Connect Custom Domain
1. In **Settings → Pages → Custom domain**, enter `luxenoirbeauty.shop`
2. Add these DNS records at your registrar:

| Type  | Name | Value                  |
|-------|------|------------------------|
| A     | @    | 185.199.108.153        |
| A     | @    | 185.199.109.153        |
| A     | @    | 185.199.110.153        |
| A     | @    | 185.199.111.153        |
| CNAME | www  | YOUR_USERNAME.github.io|

3. Check **Enforce HTTPS** ✅

---

## 📁 File Structure

```
luxenoirbeauty/
├── index.html              ← Homepage: hero, category filter, product grid
├── checkout.html           ← Stripe-ready secure checkout + WhatsApp order
├── about.html              ← Brand story / Maison page
├── contact.html            ← Contact form
├── shipping.html           ← Shipping policy
├── returns.html            ← Returns & refunds
├── terms.html              ← Terms of service
├── privacy.html            ← GDPR privacy policy
├── cookies.html            ← Cookie policy
├── sitemap.xml             ← Google Search Console ready
├── robots.txt              ← SEO crawler rules
├── assets/
│   ├── styles.css          ← Luxury black + gold design system
│   ├── app.js              ← Cart, modal, filter logic
│   └── products.json       ← Single source of truth for all products
└── product/                ← 200 individual product pages (SEO)
    ├── chanel-no5.html
    ├── dior-sauvage.html
    ├── tom-ford-black-orchid-100ml.html
    └── ... (200 total)
```

---

## ✨ Features

- 🛒 **Add to Cart / Buy Now** with slide-in cart drawer
- 🔍 **Category filtering** — Fragrance · Skincare · Makeup · Haircare · Nails
- 🪟 **Product detail modal** — quick view without leaving the page
- 📦 **Persistent cart** (localStorage) with quantity controls
- 💬 **WhatsApp ordering** — sends full cart to +254 786 781 665
- 📱 **Responsive & mobile-first** — works on all devices
- 🖤 **Luxury aesthetic** — Playfair Display + Cormorant Garamond + Inter
- 🌍 **15+ ship-to countries** at checkout
- 🔒 **GDPR compliant** — Privacy, Cookies, Terms pages included
- 🗺️ **Sitemap + robots.txt** — Google Search Console ready

---

## 💳 Going Live — Payments

The checkout has a clearly marked `PAYMENT INTEGRATION POINT`. To accept real payments:

1. Create a **Stripe** account at [stripe.com](https://stripe.com)
2. Complete KYC with your business identity + bank account
3. Deploy a backend endpoint `/api/create-checkout-session` (Stripe has official examples in Node/Python/PHP)
4. Replace the demo `alert()` in `checkout.html` with:

```js
const r = await fetch('/api/create-checkout-session', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ cart: c, customer: fd })
});
const { url } = await r.json();
location.href = url;
```

> ⚠️ Payouts go to your business bank account configured inside **Stripe Dashboard → Settings → Payouts**. Never hard-code IBANs in frontend code.

---

## 🛠 Tech Stack

- **Pure HTML + CSS + Vanilla JS** — zero dependencies, zero build step
- **Fonts** — Google Fonts (Playfair Display, Cormorant Garamond, Inter)
- **Images** — Unsplash (free, no attribution required for commercial use)
- **Hosting** — GitHub Pages (free) · Works also on Netlify, Vercel, Cloudflare Pages

---

© 2026 LUXE NOIR BEAUTY · Paris · All rights reserved
